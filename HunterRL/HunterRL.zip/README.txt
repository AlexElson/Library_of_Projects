Welcome to HunterRL!
The goal of this game is to hunt down animals. 
Specifically Rabbits and Wolves.

Use the Numpad to move around.
Pressing 5 will pass a turn.
Pressing p will allow you to pick things up.
Pressing o will allow you to open and close doors.
Pressing d will allow you to drop items.
Pressing i will allow you to see your inventory.
Pressing a will allow you to attack with what is equipped.
Pressing e will allow you to equip things.
Pressing E will unequip the item you have equipped.
Pressing t will allow you to throw items.
Pressing s while having a rifle equipped will allow you to shoot it.
Pressing 0 (Zero) while preforming an action will cancel it.

Rabbits are attracted by carrots.
Wolves are attracted by rabbit corpses.

When the Tracker is equipped, you will be able to see enemies in the shadows.
Rifles can be found around deceased hunters in the wilderness.

(This game was made during the 2012 7 Day Roguelike Challenge)